import math
import requests
def lonlat_distance(a, b):
    query = 'https://geocode-maps.yandex.ru/1.x/?format=json&geocode='+ a
    response = requests.get(query)
    response_pos = response.json()
    a_cor = response_pos['response']['GeoObjectCollection']['featureMember'][0]['GeoObject']['Point']['pos']   
    
    query = 'https://geocode-maps.yandex.ru/1.x/?format=json&geocode='+ b
    response = requests.get(query)
    response_pos = response.json()
    b_cor = response_pos['response']['GeoObjectCollection']['featureMember'][0]['GeoObject']['Point']['pos']    
    degree_to_meters_factor = 111 * 1000 # 111 километров в метрах
    a_lon, a_lat = list(map(lambda x:float(x),a_cor.split(' ')))
    b_lon, b_lat = list(map(lambda x:float(x),b_cor.split(' ')))

    # Берем среднюю по широте точку и считаем коэффициент для нее.
    radians_lattitude = math.radians((a_lat + b_lat) / 2.)
    lat_lon_factor = math.cos(radians_lattitude)

    # Вычисляем смещения в метрах по вертикали и горизонтали.
    dx = abs(a_lon - b_lon) * degree_to_meters_factor * lat_lon_factor
    dy = abs(a_lat - b_lat) * degree_to_meters_factor

    # Вычисляем расстояние между точками.
    distance = math.sqrt(dx * dx + dy * dy)

    return distance