from telegram.ext import Updater, MessageHandler, Filters,CommandHandler,ConversationHandler
import random
from Search_hotels import search_hotel
from Search_doct import search_doct
from Lanch import lanch_search
from Distance import lonlat_distance
towns = ['Сочи','Москва','Севастополь','Санкт-петербург','Магадан']
class Day:
    def __init__(self,plan,points):
        self.points = points
        self.plan = plan
    def map(self):
        points = []
        for i in self.points:
            points.append(str(i[0]) + ',' + str(i[1]))
        babl = ''
        for i in self.points:
            babl += str(i[0]) + ',' + str(i[1]) + ',pm2ntm~'
        babl = babl.strip('~')
        return 'https://static-maps.yandex.ru/1.x/?l=map&pl=' + ','.join(points) + '&pt=' + babl

def start(bot,update):
    update.message.reply_text(
                "Хотите отправиться в отпуск? \n Я вам помогу выбрать отель и составить план ваших развлечений.\n Напишите каков бюджет вашего отпуска.")
    return 1
def money(bot,update,user_data):
    user_data['money'] = int(update.message.text)
    if user_data['money'] <20000:
        update.message.reply_text(
                            "Это слишком мало может быть больше?")    
        return 1
    update.message.reply_text(
                    "Сколько дней длится ваш отпуск?")
    return 2
def days(bot,update,user_data):
    user_data['days'] = int(update.message.text)
    
    update.message.reply_text(
                        "В какой город вы хотите отправиться? Я Предлагаю вам "+random.choice(towns))   
    return 3
def hotels(bots,update,user_data):
    user_data['town'] = update.message.text
    otvet = "Осталось выбрать отель. Я вам предлагаю несколько отелей \n"
    user_data['hotels'] = search_hotel(user_data['town'])
    for i in user_data['hotels']:
        #print(i)
        #print(i['Имя'])
        otvet+=i['Имя'].capitalize()+'\n'
    otvet+=" , чтобы узнать об отеле больше просто напишите его название"
    update.message.reply_text(
        otvet)     
    return 4
def hotel_choice(bot,update,user_data):
    user_data['choice'] = update.message.text.lower()
    otvet = ''
    for i in user_data['hotels']:
        if i['Имя'] == user_data['choice']:
            user_data['hotel'] = i
            otvet += 'Имя: '+i['Имя']+'\n'
            otvet += 'Адрес: '+i['Адрес']+'\n'
            otvet += 'Телефон' +i['Телефон']+'\n'
            otvet+= 'Дополнительная информация'+'\n'
            for j in i['Доп. Информация'].keys():
                if i['Доп. Информация'][j] == True:
                    otvet+= j +': Присутствует' +'\n'
                elif i['Доп. Информация'][j] == False:
                    continue
                else:
                    otvet+= j +': '+i['Доп. Информация'][j]+'\n'
    if otvet == '':
        update.message.reply_text('Возможно вы ошиблись с названием? Попробуйте еще раз')
        return 4
    else:
        update.message.reply_text(
            'Информация по отелю '+user_data['choice']+'\n'+
            otvet+'Вам подходит этот отель?')      
        return 5
def again_choice(bot,update,user_data):
    user_data['tec'] = update.message.text
    if user_data['tec'].lower() == 'нет':
        otvet = "Какой же выбрать? \n"
        user_data['hotels'] = search_hotel(user_data['town'])
        for i in user_data['hotels']:
            #print(i)
            #print(i['Имя'])
            otvet+=i['Имя']+'\n'
        otvet+=" , чтобы узнать об отеле больше просто напишите его название"
        update.message.reply_text(
            otvet)     
        return 4  
    elif user_data['tec'].lower() == 'да':
        update.message.reply_text('Отель выбран. Создать план отдыха?')
        return 6
def program(bot, update,user_data):
    update.message.reply_text('Ждите ,я думаю.')
    try:
        if update.message.text.lower() == 'да':
            #print(user_data['town'])
            plan = search_doct(user_data['town'])
            chet_plan = 0
            rest_to_hotel = lanch_search(user_data['hotel']['Адрес'])
            lanched_for_hotel = False
            if 'ресторан' in user_data['hotel']['Доп. Информация'].keys():
                if user_data['hotel']['Доп. Информация']['ресторан']:
                    lanched_for_hotel = {'Имя':'ресторане отеля','coords': user_data['hotel']['coords']}
            per = user_data['hotel']['Адрес']
            if not lanched_for_hotel:
                minimum = 1000000000000
                min_lanch = ''
                for j in lanch_search(user_data['hotel']['Адрес']):
                    dist = lonlat_distance(j['Адрес'],per)
                    if dist <minimum:
                        minimum = dist
                        min_lanch = j        
                lanched_for_hotel = min_lanch
            for i in range(user_data['days']):
                user_data[i] = {}
                user_data[i]['Points'] = [user_data['hotel']['coords']]
                koof = len(plan)//user_data['days']
                utro = 'Завтракаем в ' + lanched_for_hotel['Имя']
                user_data[i]['Points'].append(lanched_for_hotel['coords'])
                if koof>1:
                    utro += '\n Идем к достопримечательности ' +plan[chet_plan]['name']+'\n А после прогулка по городу '
                    user_data[i]['Points'].append(plan[chet_plan]['coords'])
                    chet_plan+=1
                if koof==0 and chet_plan >=len(plan)-1:
                    continue
                else:
                    doct = plan[chet_plan]
                    day ='\n Идем к интересному месту под названием ' +doct['name']+'\n А после прогулка по городу '
                    user_data[i]['Points'].append(plan[chet_plan]['coords'])
                    chet_plan+=1
                minimum = 1000000000000
                min_uch = ''
                for j in lanch_search(doct['address']):
                    dist = lonlat_distance(j['Адрес'],doct['address'])
                    if dist <minimum:
                        minimum = dist
                        min_uch = j       
                vech = 'Ужинаем в '+min_uch['Имя']+'\n А после идем в отель '
                user_data[i]['Points'].append(min_uch['coords'])
                if koof>2:
                    vech += '\n Идем к достопримечательности' +plan[chet_plan]['name']+'\n А после идем в отель'
                    user_data[i]['Points'].append(plan[chet_plan]['coords'])
                    chet_plan+=1
                user_data[i]['Описание'] = 'Утро: \n'+utro +' Днем: \n'+day+' Вечер: \n'+vech
                user_data[i] = Day(user_data[i]['Описание'],user_data[i]['Points'])
            update.message.reply_text('План отдыха создан. Напишите номер дня по которому вы хотите видеть план.')
            return 7
        elif update.message.text.lower() == 'нет':
            update.message.reply_text('Информация по вашему отдыху: \n Бюджет: '+user_data['money']+'\n Длительность: '+user_data['days']+'\n Город отдыха: '+user_data['town'])
            return ConversationHandler.END
        else:
            update.message.reply_text('Я вас не понимаю. Так да или нет?')
            return 6
    except:
        update.message.reply_text('Критическая ошибка. Попробывать еще раз?')
        return 6
def plan(bot, update,user_data):
    if 'покажи схему' == update.message.text.lower():
        if 'day_choice' not in user_data.keys():
            return 7
        print(user_data['day_choice'])
        update.message.reply_text(user_data[user_data['day_choice']].map())
    else:
        try:
            user_data['day_choice'] = int(update.message.text)-1
            #print(user_data[user_data['day_choice']])
            update.message.reply_text('План на день №'+str(user_data['day_choice']+1)+'\n'+user_data[user_data['day_choice']].plan+'\n Напишите номер дня по которому вы хотите видеть план. Также я могу показать схему вашего путешествия')
        except:
            update.message.reply_text('Я вас непонимаю попробуйте еще раз.')
        
    return 7
def stop(bot, update,user_data):
    update.message.reply_text('Информация по вашему отдыху: \n Бюджет: '+user_data['money']+'\n Длительность: '+user_data['days']+'\n Город отдыха: '+user_data['town'])
    return ConversationHandler.END
def main():
    updater = Updater("494543007:AAHCZ0ll-xEdWTdpBGzVnUga18IkXHeVTQc")
    dp = updater.dispatcher
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states = {1: [MessageHandler(Filters.text, money ,pass_user_data=True)],
                  2: [MessageHandler(Filters.text, days ,pass_user_data=True)],
                  3: [MessageHandler(Filters.text, hotels ,pass_user_data=True)],
                  4: [MessageHandler(Filters.text, hotel_choice ,pass_user_data=True)],
                  5: [MessageHandler(Filters.text, again_choice ,pass_user_data=True)],
                  6: [MessageHandler(Filters.text, program ,pass_user_data=True)],
                  7: [MessageHandler(Filters.text, plan ,pass_user_data=True)]
        },
        fallbacks = [CommandHandler('stop', stop,pass_user_data=True)]
    )
    dp.add_handler(conv_handler)
    updater.start_polling()
    updater.idle()


if __name__ == '__main__':
    main()