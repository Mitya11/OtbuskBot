import requests
def search_doct(address):
    geocoder_request = "http://geocode-maps.yandex.ru/1.x/?geocode="+address+"&format=json"
    response = None
    response = requests.get(geocoder_request)
    if response:
        json_response = response.json()
    toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]
    toponym_address = toponym["metaDataProperty"]["GeocoderMetaData"]["text"]
    toponym_coodrinates = toponym["Point"]["pos"]    
    search_api_server = "https://search-maps.yandex.ru/v1/"
    api_key = "3c4a592e-c4c0-4949-85d1-97291c87825c"
    
    address_ll = toponym_coodrinates = toponym["Point"]["pos"] 
    #print(address_ll)
    search_params = {
        "apikey": api_key,
        "text": "Достопримечательность",
        "lang": "ru_RU",
        "ll": address_ll,
        "type": "biz"
    }
    
    response = requests.get(search_api_server, params=search_params)
    if not response:
        pass
    json_response = response.json()
    siro =json_response['features']
    #print(json_response)
    doct = []
    #print(json_response)
    for i in siro:
        try:
            name = i['properties']['name']
            coords = i['geometry']['coordinates']
            address = i['properties']['CompanyMetaData']['address']
            #print(name)
            #print(address)
            informations = {}
            try:
                for j in i['properties']['CompanyMetaData']['Features']:
                    try:
                        #print(j)
                        informations[j['name']] = j['value']
                    except:
                        continue
            except:
                informations['Информация'] = 'отстствует'
            doct.append({'name':name,'address':address,'coords':coords,'informations':informations})
            
        except:
            continue
    #print(doct)
    return doct
#print(type(search_doct('Москва')[0]['coords']))